package com.hrandika.android.seng22243intro.model

data class Photo(var title: String, var thumbnailUrl: String, var url: String)